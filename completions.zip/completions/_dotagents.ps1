
using namespace System.Management.Automation
using namespace System.Management.Automation.Language

Register-ArgumentCompleter -Native -CommandName 'dotagents' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $commandElements = $commandAst.CommandElements
    $command = @(
        'dotagents'
        for ($i = 1; $i -lt $commandElements.Count; $i++) {
            $element = $commandElements[$i]
            if ($element -isnot [StringConstantExpressionAst] -or
                $element.StringConstantType -ne [StringConstantType]::BareWord -or
                $element.Value.StartsWith('-') -or
                $element.Value -eq $wordToComplete) {
                break
        }
        $element.Value
    }) -join ';'

    $completions = @(switch ($command) {
        'dotagents' {
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('-V', '-V ', [CompletionResultType]::ParameterName, 'Print version')
            [CompletionResult]::new('--version', '--version', [CompletionResultType]::ParameterName, 'Print version')
            [CompletionResult]::new('init', 'init', [CompletionResultType]::ParameterValue, 'Initialize .dotagents directory with a single package containing all the files in the current directory creating a mock templates for commands, instructions and mcp configuration')
            [CompletionResult]::new('gen-completions', 'gen-completions', [CompletionResultType]::ParameterValue, 'Generate completions for the given shell')
            [CompletionResult]::new('deploy', 'deploy', [CompletionResultType]::ParameterValue, 'Deploy templates')
            [CompletionResult]::new('skills', 'skills', [CompletionResultType]::ParameterValue, 'Manage skills')
            [CompletionResult]::new('commands', 'commands', [CompletionResultType]::ParameterValue, 'Manage commands')
            [CompletionResult]::new('undeploy', 'undeploy', [CompletionResultType]::ParameterValue, 'Remove all files deployed by the last `dotagents deploy` run')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'dotagents;init' {
            [CompletionResult]::new('--features', '--features', [CompletionResultType]::ParameterName, 'Features to scaffold. Accepts comma-separated values and/or repeated flags. Valid values: commands, instructions, mcp, skills, none. When omitted, features are chosen interactively when possible; otherwise all features are enabled. Use `none` to disable all features')
            [CompletionResult]::new('--template', '--template', [CompletionResultType]::ParameterName, 'Scaffolding template: ''starter'' (core files only) or ''with-custom-provider'' (adds mycode example). When omitted in an interactive terminal, the wizard will prompt for a choice')
            [CompletionResult]::new('-f', '-f', [CompletionResultType]::ParameterName, 'Force overwriting existing configuration')
            [CompletionResult]::new('--force', '--force', [CompletionResultType]::ParameterName, 'Force overwriting existing configuration')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help (see more with ''--help'')')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help (see more with ''--help'')')
            break
        }
        'dotagents;gen-completions' {
            [CompletionResult]::new('-s', '-s', [CompletionResultType]::ParameterName, 'Set the shell for generating completions [values: bash, elvish, fish, powerShell, zsh]')
            [CompletionResult]::new('--shell', '--shell', [CompletionResultType]::ParameterName, 'Set the shell for generating completions [values: bash, elvish, fish, powerShell, zsh]')
            [CompletionResult]::new('--to', '--to', [CompletionResultType]::ParameterName, 'Set the out directory for writing completions file')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'dotagents;deploy' {
            [CompletionResult]::new('--env', '--env', [CompletionResultType]::ParameterName, 'Custom .env file(s) to load instead of .dotagents/.env. Repeatable; later files override earlier ones on duplicate keys')
            [CompletionResult]::new('-f', '-f', [CompletionResultType]::ParameterName, 'Force overwrite all target files regardless of cache state')
            [CompletionResult]::new('--force', '--force', [CompletionResultType]::ParameterName, 'Force overwrite all target files regardless of cache state')
            [CompletionResult]::new('--no-cache', '--no-cache', [CompletionResultType]::ParameterName, 'Skip hash comparison; always re-render and write all target files. cache.toml is still written at the end of the run')
            [CompletionResult]::new('--gitignore', '--gitignore', [CompletionResultType]::ParameterName, 'Always update .gitignore without prompting')
            [CompletionResult]::new('--no-gitignore', '--no-gitignore', [CompletionResultType]::ParameterName, 'Never update .gitignore')
            [CompletionResult]::new('--offline', '--offline', [CompletionResultType]::ParameterName, 'Skip the remote registry fetch; resolve missing templates from the local cache only. Errors if a required template has not been cached by a previous online deploy')
            [CompletionResult]::new('--dry-run', '--dry-run', [CompletionResultType]::ParameterName, 'Preview what would be deployed without writing any files, saving cache, or updating .gitignore')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'dotagents;skills' {
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('add', 'add', [CompletionResultType]::ParameterValue, 'Install a skill from skills.sh or a GitHub owner/repo into .dotagents/skills/')
            [CompletionResult]::new('new', 'new', [CompletionResultType]::ParameterValue, 'Create a new local skill scaffold in .dotagents/skills/')
            [CompletionResult]::new('rm', 'rm', [CompletionResultType]::ParameterValue, 'Remove a local skill from .dotagents/skills/')
            [CompletionResult]::new('ls', 'ls', [CompletionResultType]::ParameterValue, 'List local skills in .dotagents/skills/')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'dotagents;skills;add' {
            [CompletionResult]::new('-r', '-r', [CompletionResultType]::ParameterName, 'Package runner to use for this invocation [npm, pnpm, yarn, bun]')
            [CompletionResult]::new('--runner', '--runner', [CompletionResultType]::ParameterName, 'Package runner to use for this invocation [npm, pnpm, yarn, bun]')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'dotagents;skills;new' {
            [CompletionResult]::new('-d', '-d', [CompletionResultType]::ParameterName, 'Short description of the skill')
            [CompletionResult]::new('--description', '--description', [CompletionResultType]::ParameterName, 'Short description of the skill')
            [CompletionResult]::new('-l', '-l', [CompletionResultType]::ParameterName, 'License for the skill (e.g. MIT)')
            [CompletionResult]::new('--license', '--license', [CompletionResultType]::ParameterName, 'License for the skill (e.g. MIT)')
            [CompletionResult]::new('--compatibility', '--compatibility', [CompletionResultType]::ParameterName, 'Compatibility notes for the skill')
            [CompletionResult]::new('-f', '-f', [CompletionResultType]::ParameterName, 'Overwrite if the skill already exists')
            [CompletionResult]::new('--force', '--force', [CompletionResultType]::ParameterName, 'Overwrite if the skill already exists')
            [CompletionResult]::new('--deploy', '--deploy', [CompletionResultType]::ParameterName, 'Run deploy after creating the skill')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'dotagents;skills;rm' {
            [CompletionResult]::new('-f', '-f', [CompletionResultType]::ParameterName, 'Skip the confirmation prompt')
            [CompletionResult]::new('--force', '--force', [CompletionResultType]::ParameterName, 'Skip the confirmation prompt')
            [CompletionResult]::new('--deploy', '--deploy', [CompletionResultType]::ParameterName, 'Run deploy after removing the skill')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'dotagents;skills;ls' {
            [CompletionResult]::new('--full', '--full', [CompletionResultType]::ParameterName, 'Show full descriptions (word-wrapped) instead of truncating')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'dotagents;skills;help' {
            [CompletionResult]::new('add', 'add', [CompletionResultType]::ParameterValue, 'Install a skill from skills.sh or a GitHub owner/repo into .dotagents/skills/')
            [CompletionResult]::new('new', 'new', [CompletionResultType]::ParameterValue, 'Create a new local skill scaffold in .dotagents/skills/')
            [CompletionResult]::new('rm', 'rm', [CompletionResultType]::ParameterValue, 'Remove a local skill from .dotagents/skills/')
            [CompletionResult]::new('ls', 'ls', [CompletionResultType]::ParameterValue, 'List local skills in .dotagents/skills/')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'dotagents;skills;help;add' {
            break
        }
        'dotagents;skills;help;new' {
            break
        }
        'dotagents;skills;help;rm' {
            break
        }
        'dotagents;skills;help;ls' {
            break
        }
        'dotagents;skills;help;help' {
            break
        }
        'dotagents;commands' {
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('new', 'new', [CompletionResultType]::ParameterValue, 'Create a new command in .dotagents/commands/')
            [CompletionResult]::new('rm', 'rm', [CompletionResultType]::ParameterValue, 'Remove a command from .dotagents/commands/')
            [CompletionResult]::new('ls', 'ls', [CompletionResultType]::ParameterValue, 'List commands in .dotagents/commands/')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'dotagents;commands;new' {
            [CompletionResult]::new('-d', '-d', [CompletionResultType]::ParameterName, 'Short description of the command')
            [CompletionResult]::new('--description', '--description', [CompletionResultType]::ParameterName, 'Short description of the command')
            [CompletionResult]::new('-c', '-c', [CompletionResultType]::ParameterName, 'Category for the command')
            [CompletionResult]::new('--category', '--category', [CompletionResultType]::ParameterName, 'Category for the command')
            [CompletionResult]::new('-t', '-t', [CompletionResultType]::ParameterName, 'Comma-separated tags for the command')
            [CompletionResult]::new('--tags', '--tags', [CompletionResultType]::ParameterName, 'Comma-separated tags for the command')
            [CompletionResult]::new('-f', '-f', [CompletionResultType]::ParameterName, 'Overwrite if the file already exists')
            [CompletionResult]::new('--force', '--force', [CompletionResultType]::ParameterName, 'Overwrite if the file already exists')
            [CompletionResult]::new('--deploy', '--deploy', [CompletionResultType]::ParameterName, 'Run deploy after creating the command')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'dotagents;commands;rm' {
            [CompletionResult]::new('-f', '-f', [CompletionResultType]::ParameterName, 'Skip the confirmation prompt')
            [CompletionResult]::new('--force', '--force', [CompletionResultType]::ParameterName, 'Skip the confirmation prompt')
            [CompletionResult]::new('--deploy', '--deploy', [CompletionResultType]::ParameterName, 'Run deploy after removing the command')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'dotagents;commands;ls' {
            [CompletionResult]::new('--full', '--full', [CompletionResultType]::ParameterName, 'Show full descriptions (word-wrapped) instead of truncating')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'dotagents;commands;help' {
            [CompletionResult]::new('new', 'new', [CompletionResultType]::ParameterValue, 'Create a new command in .dotagents/commands/')
            [CompletionResult]::new('rm', 'rm', [CompletionResultType]::ParameterValue, 'Remove a command from .dotagents/commands/')
            [CompletionResult]::new('ls', 'ls', [CompletionResultType]::ParameterValue, 'List commands in .dotagents/commands/')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'dotagents;commands;help;new' {
            break
        }
        'dotagents;commands;help;rm' {
            break
        }
        'dotagents;commands;help;ls' {
            break
        }
        'dotagents;commands;help;help' {
            break
        }
        'dotagents;undeploy' {
            [CompletionResult]::new('-f', '-f', [CompletionResultType]::ParameterName, 'Skip confirmation prompt and delete user-edited files without asking')
            [CompletionResult]::new('--force', '--force', [CompletionResultType]::ParameterName, 'Skip confirmation prompt and delete user-edited files without asking')
            [CompletionResult]::new('--no-gitignore', '--no-gitignore', [CompletionResultType]::ParameterName, 'Do not remove entries from .gitignore')
            [CompletionResult]::new('--dry-run', '--dry-run', [CompletionResultType]::ParameterName, 'Preview what would be undeployed without deleting any files, clearing cache, or touching .gitignore')
            [CompletionResult]::new('-v', '-v', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('--verbose', '--verbose', [CompletionResultType]::ParameterName, 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run')
            [CompletionResult]::new('-q', '-q', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('--quiet', '--quiet', [CompletionResultType]::ParameterName, 'Quiet - only print errors')
            [CompletionResult]::new('-h', '-h', [CompletionResultType]::ParameterName, 'Print help')
            [CompletionResult]::new('--help', '--help', [CompletionResultType]::ParameterName, 'Print help')
            break
        }
        'dotagents;help' {
            [CompletionResult]::new('init', 'init', [CompletionResultType]::ParameterValue, 'Initialize .dotagents directory with a single package containing all the files in the current directory creating a mock templates for commands, instructions and mcp configuration')
            [CompletionResult]::new('gen-completions', 'gen-completions', [CompletionResultType]::ParameterValue, 'Generate completions for the given shell')
            [CompletionResult]::new('deploy', 'deploy', [CompletionResultType]::ParameterValue, 'Deploy templates')
            [CompletionResult]::new('skills', 'skills', [CompletionResultType]::ParameterValue, 'Manage skills')
            [CompletionResult]::new('commands', 'commands', [CompletionResultType]::ParameterValue, 'Manage commands')
            [CompletionResult]::new('undeploy', 'undeploy', [CompletionResultType]::ParameterValue, 'Remove all files deployed by the last `dotagents deploy` run')
            [CompletionResult]::new('help', 'help', [CompletionResultType]::ParameterValue, 'Print this message or the help of the given subcommand(s)')
            break
        }
        'dotagents;help;init' {
            break
        }
        'dotagents;help;gen-completions' {
            break
        }
        'dotagents;help;deploy' {
            break
        }
        'dotagents;help;skills' {
            [CompletionResult]::new('add', 'add', [CompletionResultType]::ParameterValue, 'Install a skill from skills.sh or a GitHub owner/repo into .dotagents/skills/')
            [CompletionResult]::new('new', 'new', [CompletionResultType]::ParameterValue, 'Create a new local skill scaffold in .dotagents/skills/')
            [CompletionResult]::new('rm', 'rm', [CompletionResultType]::ParameterValue, 'Remove a local skill from .dotagents/skills/')
            [CompletionResult]::new('ls', 'ls', [CompletionResultType]::ParameterValue, 'List local skills in .dotagents/skills/')
            break
        }
        'dotagents;help;skills;add' {
            break
        }
        'dotagents;help;skills;new' {
            break
        }
        'dotagents;help;skills;rm' {
            break
        }
        'dotagents;help;skills;ls' {
            break
        }
        'dotagents;help;commands' {
            [CompletionResult]::new('new', 'new', [CompletionResultType]::ParameterValue, 'Create a new command in .dotagents/commands/')
            [CompletionResult]::new('rm', 'rm', [CompletionResultType]::ParameterValue, 'Remove a command from .dotagents/commands/')
            [CompletionResult]::new('ls', 'ls', [CompletionResultType]::ParameterValue, 'List commands in .dotagents/commands/')
            break
        }
        'dotagents;help;commands;new' {
            break
        }
        'dotagents;help;commands;rm' {
            break
        }
        'dotagents;help;commands;ls' {
            break
        }
        'dotagents;help;undeploy' {
            break
        }
        'dotagents;help;help' {
            break
        }
    })

    $completions.Where{ $_.CompletionText -like "$wordToComplete*" } |
        Sort-Object -Property ListItemText
}
