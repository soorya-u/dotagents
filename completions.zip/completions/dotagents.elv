
use builtin;
use str;

set edit:completion:arg-completer[dotagents] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'dotagents'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'dotagents'= {
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
            cand -V 'Print version'
            cand --version 'Print version'
            cand init 'Initialize .dotagents directory with a single package containing all the files in the current directory creating a mock templates for commands, instructions and mcp configuration'
            cand gen-completions 'Generate completions for the given shell'
            cand deploy 'Deploy templates'
            cand skills 'Manage skills'
            cand commands 'Manage commands'
            cand undeploy 'Remove all files deployed by the last `dotagents deploy` run'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'dotagents;init'= {
            cand --features 'Features to scaffold. Accepts comma-separated values and/or repeated flags. Valid values: commands, instructions, mcp, skills, none. When omitted, features are chosen interactively when possible; otherwise all features are enabled. Use `none` to disable all features'
            cand --template 'Scaffolding template: ''starter'' (core files only) or ''with-custom-provider'' (adds mycode example). When omitted in an interactive terminal, the wizard will prompt for a choice'
            cand -f 'Force overwriting existing configuration'
            cand --force 'Force overwriting existing configuration'
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help (see more with ''--help'')'
            cand --help 'Print help (see more with ''--help'')'
        }
        &'dotagents;gen-completions'= {
            cand -s 'Set the shell for generating completions [values: bash, elvish, fish, powerShell, zsh]'
            cand --shell 'Set the shell for generating completions [values: bash, elvish, fish, powerShell, zsh]'
            cand --to 'Set the out directory for writing completions file'
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'dotagents;deploy'= {
            cand --env 'Custom .env file(s) to load instead of .dotagents/.env. Repeatable; later files override earlier ones on duplicate keys'
            cand -f 'Force overwrite all target files regardless of cache state'
            cand --force 'Force overwrite all target files regardless of cache state'
            cand --no-cache 'Skip hash comparison; always re-render and write all target files. cache.toml is still written at the end of the run'
            cand --gitignore 'Always update .gitignore without prompting'
            cand --no-gitignore 'Never update .gitignore'
            cand --offline 'Skip the remote registry fetch; resolve missing templates from the local cache only. Errors if a required template has not been cached by a previous online deploy'
            cand --dry-run 'Preview what would be deployed without writing any files, saving cache, or updating .gitignore'
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'dotagents;skills'= {
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
            cand add 'Install a skill from skills.sh or a GitHub owner/repo into .dotagents/skills/'
            cand new 'Create a new local skill scaffold in .dotagents/skills/'
            cand rm 'Remove a local skill from .dotagents/skills/'
            cand ls 'List local skills in .dotagents/skills/'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'dotagents;skills;add'= {
            cand -r 'Package runner to use for this invocation [npm, pnpm, yarn, bun]'
            cand --runner 'Package runner to use for this invocation [npm, pnpm, yarn, bun]'
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'dotagents;skills;new'= {
            cand -d 'Short description of the skill'
            cand --description 'Short description of the skill'
            cand -l 'License for the skill (e.g. MIT)'
            cand --license 'License for the skill (e.g. MIT)'
            cand --compatibility 'Compatibility notes for the skill'
            cand -f 'Overwrite if the skill already exists'
            cand --force 'Overwrite if the skill already exists'
            cand --deploy 'Run deploy after creating the skill'
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'dotagents;skills;rm'= {
            cand -f 'Skip the confirmation prompt'
            cand --force 'Skip the confirmation prompt'
            cand --deploy 'Run deploy after removing the skill'
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'dotagents;skills;ls'= {
            cand --full 'Show full descriptions (word-wrapped) instead of truncating'
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'dotagents;skills;help'= {
            cand add 'Install a skill from skills.sh or a GitHub owner/repo into .dotagents/skills/'
            cand new 'Create a new local skill scaffold in .dotagents/skills/'
            cand rm 'Remove a local skill from .dotagents/skills/'
            cand ls 'List local skills in .dotagents/skills/'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'dotagents;skills;help;add'= {
        }
        &'dotagents;skills;help;new'= {
        }
        &'dotagents;skills;help;rm'= {
        }
        &'dotagents;skills;help;ls'= {
        }
        &'dotagents;skills;help;help'= {
        }
        &'dotagents;commands'= {
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
            cand new 'Create a new command in .dotagents/commands/'
            cand rm 'Remove a command from .dotagents/commands/'
            cand ls 'List commands in .dotagents/commands/'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'dotagents;commands;new'= {
            cand -d 'Short description of the command'
            cand --description 'Short description of the command'
            cand -c 'Category for the command'
            cand --category 'Category for the command'
            cand -t 'Comma-separated tags for the command'
            cand --tags 'Comma-separated tags for the command'
            cand -f 'Overwrite if the file already exists'
            cand --force 'Overwrite if the file already exists'
            cand --deploy 'Run deploy after creating the command'
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'dotagents;commands;rm'= {
            cand -f 'Skip the confirmation prompt'
            cand --force 'Skip the confirmation prompt'
            cand --deploy 'Run deploy after removing the command'
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'dotagents;commands;ls'= {
            cand --full 'Show full descriptions (word-wrapped) instead of truncating'
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'dotagents;commands;help'= {
            cand new 'Create a new command in .dotagents/commands/'
            cand rm 'Remove a command from .dotagents/commands/'
            cand ls 'List commands in .dotagents/commands/'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'dotagents;commands;help;new'= {
        }
        &'dotagents;commands;help;rm'= {
        }
        &'dotagents;commands;help;ls'= {
        }
        &'dotagents;commands;help;help'= {
        }
        &'dotagents;undeploy'= {
            cand -f 'Skip confirmation prompt and delete user-edited files without asking'
            cand --force 'Skip confirmation prompt and delete user-edited files without asking'
            cand --no-gitignore 'Do not remove entries from .gitignore'
            cand --dry-run 'Preview what would be undeployed without deleting any files, clearing cache, or touching .gitignore'
            cand -v 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand --verbose 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter''s run'
            cand -q 'Quiet - only print errors'
            cand --quiet 'Quiet - only print errors'
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'dotagents;help'= {
            cand init 'Initialize .dotagents directory with a single package containing all the files in the current directory creating a mock templates for commands, instructions and mcp configuration'
            cand gen-completions 'Generate completions for the given shell'
            cand deploy 'Deploy templates'
            cand skills 'Manage skills'
            cand commands 'Manage commands'
            cand undeploy 'Remove all files deployed by the last `dotagents deploy` run'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'dotagents;help;init'= {
        }
        &'dotagents;help;gen-completions'= {
        }
        &'dotagents;help;deploy'= {
        }
        &'dotagents;help;skills'= {
            cand add 'Install a skill from skills.sh or a GitHub owner/repo into .dotagents/skills/'
            cand new 'Create a new local skill scaffold in .dotagents/skills/'
            cand rm 'Remove a local skill from .dotagents/skills/'
            cand ls 'List local skills in .dotagents/skills/'
        }
        &'dotagents;help;skills;add'= {
        }
        &'dotagents;help;skills;new'= {
        }
        &'dotagents;help;skills;rm'= {
        }
        &'dotagents;help;skills;ls'= {
        }
        &'dotagents;help;commands'= {
            cand new 'Create a new command in .dotagents/commands/'
            cand rm 'Remove a command from .dotagents/commands/'
            cand ls 'List commands in .dotagents/commands/'
        }
        &'dotagents;help;commands;new'= {
        }
        &'dotagents;help;commands;rm'= {
        }
        &'dotagents;help;commands;ls'= {
        }
        &'dotagents;help;undeploy'= {
        }
        &'dotagents;help;help'= {
        }
    ]
    $completions[$command]
}
