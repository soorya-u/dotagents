# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_dotagents_global_optspecs
	string join \n v/verbose q/quiet h/help V/version
end

function __fish_dotagents_needs_command
	# Figure out if the current invocation already has a command.
	set -l cmd (commandline -opc)
	set -e cmd[1]
	argparse -s (__fish_dotagents_global_optspecs) -- $cmd 2>/dev/null
	or return
	if set -q argv[1]
		# Also print the command, so this can be used to figure out what it is.
		echo $argv[1]
		return 1
	end
	return 0
end

function __fish_dotagents_using_subcommand
	set -l cmd (__fish_dotagents_needs_command)
	test -z "$cmd"
	and return 1
	contains -- $cmd[1] $argv
end

complete -c dotagents -n "__fish_dotagents_needs_command" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_needs_command" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_needs_command" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_needs_command" -s V -l version -d 'Print version'
complete -c dotagents -n "__fish_dotagents_needs_command" -f -a "init" -d 'Initialize .dotagents directory with a single package containing all the files in the current directory creating a mock templates for commands, instructions and mcp configuration'
complete -c dotagents -n "__fish_dotagents_needs_command" -f -a "gen-completions" -d 'Generate completions for the given shell'
complete -c dotagents -n "__fish_dotagents_needs_command" -f -a "deploy" -d 'Deploy templates'
complete -c dotagents -n "__fish_dotagents_needs_command" -f -a "skills" -d 'Manage skills'
complete -c dotagents -n "__fish_dotagents_needs_command" -f -a "commands" -d 'Manage commands'
complete -c dotagents -n "__fish_dotagents_needs_command" -f -a "undeploy" -d 'Remove all files deployed by the last `dotagents deploy` run'
complete -c dotagents -n "__fish_dotagents_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c dotagents -n "__fish_dotagents_using_subcommand init" -l features -d 'Features to scaffold. Accepts comma-separated values and/or repeated flags. Valid values: commands, instructions, mcp, skills, none. When omitted, features are chosen interactively when possible; otherwise all features are enabled. Use `none` to disable all features' -r -f -a "commands\t'Enable command templating'
instructions\t'Enable instruction templating'
mcp\t'Enable MCP templating'
skills\t'Enable skill templating'
none\t'Disable all features (exclusive — cannot be combined with other values)'"
complete -c dotagents -n "__fish_dotagents_using_subcommand init" -l template -d 'Scaffolding template: \'starter\' (core files only) or \'with-custom-provider\' (adds mycode example). When omitted in an interactive terminal, the wizard will prompt for a choice' -r -f -a "starter\t'Core files only — no example custom-provider templates'
with-custom-provider\t'Core files plus a mycode example provider (templates/ dir + local.config.toml provider block)'"
complete -c dotagents -n "__fish_dotagents_using_subcommand init" -s f -l force -d 'Force overwriting existing configuration'
complete -c dotagents -n "__fish_dotagents_using_subcommand init" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand init" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand init" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c dotagents -n "__fish_dotagents_using_subcommand gen-completions" -s s -l shell -d 'Set the shell for generating completions [values: bash, elvish, fish, powerShell, zsh]' -r -f -a "bash\t''
elvish\t''
fish\t''
powershell\t''
zsh\t''"
complete -c dotagents -n "__fish_dotagents_using_subcommand gen-completions" -l to -d 'Set the out directory for writing completions file' -r -F
complete -c dotagents -n "__fish_dotagents_using_subcommand gen-completions" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand gen-completions" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand gen-completions" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand deploy" -l env -d 'Custom .env file(s) to load instead of .dotagents/.env. Repeatable; later files override earlier ones on duplicate keys' -r -F
complete -c dotagents -n "__fish_dotagents_using_subcommand deploy" -s f -l force -d 'Force overwrite all target files regardless of cache state'
complete -c dotagents -n "__fish_dotagents_using_subcommand deploy" -l no-cache -d 'Skip hash comparison; always re-render and write all target files. cache.toml is still written at the end of the run'
complete -c dotagents -n "__fish_dotagents_using_subcommand deploy" -l gitignore -d 'Always update .gitignore without prompting'
complete -c dotagents -n "__fish_dotagents_using_subcommand deploy" -l no-gitignore -d 'Never update .gitignore'
complete -c dotagents -n "__fish_dotagents_using_subcommand deploy" -l offline -d 'Skip the remote registry fetch; resolve missing templates from the local cache only. Errors if a required template has not been cached by a previous online deploy'
complete -c dotagents -n "__fish_dotagents_using_subcommand deploy" -l dry-run -d 'Preview what would be deployed without writing any files, saving cache, or updating .gitignore'
complete -c dotagents -n "__fish_dotagents_using_subcommand deploy" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand deploy" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand deploy" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and not __fish_seen_subcommand_from add new rm ls help" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and not __fish_seen_subcommand_from add new rm ls help" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and not __fish_seen_subcommand_from add new rm ls help" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and not __fish_seen_subcommand_from add new rm ls help" -f -a "add" -d 'Install a skill from skills.sh or a GitHub owner/repo into .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and not __fish_seen_subcommand_from add new rm ls help" -f -a "new" -d 'Create a new local skill scaffold in .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and not __fish_seen_subcommand_from add new rm ls help" -f -a "rm" -d 'Remove a local skill from .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and not __fish_seen_subcommand_from add new rm ls help" -f -a "ls" -d 'List local skills in .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and not __fish_seen_subcommand_from add new rm ls help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from add" -s r -l runner -d 'Package runner to use for this invocation [npm, pnpm, yarn, bun]' -r -f -a "npm\t''
pnpm\t''
yarn\t''
bun\t''"
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from add" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from add" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from new" -s d -l description -d 'Short description of the skill' -r
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from new" -s l -l license -d 'License for the skill (e.g. MIT)' -r
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from new" -l compatibility -d 'Compatibility notes for the skill' -r
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from new" -s f -l force -d 'Overwrite if the skill already exists'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from new" -l deploy -d 'Run deploy after creating the skill'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from new" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from new" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from new" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from rm" -s f -l force -d 'Skip the confirmation prompt'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from rm" -l deploy -d 'Run deploy after removing the skill'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from rm" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from rm" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from rm" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from ls" -l full -d 'Show full descriptions (word-wrapped) instead of truncating'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from ls" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from ls" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from ls" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from help" -f -a "add" -d 'Install a skill from skills.sh or a GitHub owner/repo into .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from help" -f -a "new" -d 'Create a new local skill scaffold in .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from help" -f -a "rm" -d 'Remove a local skill from .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from help" -f -a "ls" -d 'List local skills in .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand skills; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and not __fish_seen_subcommand_from new rm ls help" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and not __fish_seen_subcommand_from new rm ls help" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and not __fish_seen_subcommand_from new rm ls help" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and not __fish_seen_subcommand_from new rm ls help" -f -a "new" -d 'Create a new command in .dotagents/commands/'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and not __fish_seen_subcommand_from new rm ls help" -f -a "rm" -d 'Remove a command from .dotagents/commands/'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and not __fish_seen_subcommand_from new rm ls help" -f -a "ls" -d 'List commands in .dotagents/commands/'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and not __fish_seen_subcommand_from new rm ls help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from new" -s d -l description -d 'Short description of the command' -r
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from new" -s c -l category -d 'Category for the command' -r
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from new" -s t -l tags -d 'Comma-separated tags for the command' -r
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from new" -s f -l force -d 'Overwrite if the file already exists'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from new" -l deploy -d 'Run deploy after creating the command'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from new" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from new" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from new" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from rm" -s f -l force -d 'Skip the confirmation prompt'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from rm" -l deploy -d 'Run deploy after removing the command'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from rm" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from rm" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from rm" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from ls" -l full -d 'Show full descriptions (word-wrapped) instead of truncating'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from ls" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from ls" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from ls" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from help" -f -a "new" -d 'Create a new command in .dotagents/commands/'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from help" -f -a "rm" -d 'Remove a command from .dotagents/commands/'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from help" -f -a "ls" -d 'List commands in .dotagents/commands/'
complete -c dotagents -n "__fish_dotagents_using_subcommand commands; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c dotagents -n "__fish_dotagents_using_subcommand undeploy" -s f -l force -d 'Skip confirmation prompt and delete user-edited files without asking'
complete -c dotagents -n "__fish_dotagents_using_subcommand undeploy" -l no-gitignore -d 'Do not remove entries from .gitignore'
complete -c dotagents -n "__fish_dotagents_using_subcommand undeploy" -l dry-run -d 'Preview what would be undeployed without deleting any files, clearing cache, or touching .gitignore'
complete -c dotagents -n "__fish_dotagents_using_subcommand undeploy" -s v -l verbose -d 'Verbosity level - specify up to 3 times to get more detailed output. Specifying at least once prints the differences between what was before and after Dotter\'s run'
complete -c dotagents -n "__fish_dotagents_using_subcommand undeploy" -s q -l quiet -d 'Quiet - only print errors'
complete -c dotagents -n "__fish_dotagents_using_subcommand undeploy" -s h -l help -d 'Print help'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and not __fish_seen_subcommand_from init gen-completions deploy skills commands undeploy help" -f -a "init" -d 'Initialize .dotagents directory with a single package containing all the files in the current directory creating a mock templates for commands, instructions and mcp configuration'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and not __fish_seen_subcommand_from init gen-completions deploy skills commands undeploy help" -f -a "gen-completions" -d 'Generate completions for the given shell'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and not __fish_seen_subcommand_from init gen-completions deploy skills commands undeploy help" -f -a "deploy" -d 'Deploy templates'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and not __fish_seen_subcommand_from init gen-completions deploy skills commands undeploy help" -f -a "skills" -d 'Manage skills'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and not __fish_seen_subcommand_from init gen-completions deploy skills commands undeploy help" -f -a "commands" -d 'Manage commands'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and not __fish_seen_subcommand_from init gen-completions deploy skills commands undeploy help" -f -a "undeploy" -d 'Remove all files deployed by the last `dotagents deploy` run'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and not __fish_seen_subcommand_from init gen-completions deploy skills commands undeploy help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and __fish_seen_subcommand_from skills" -f -a "add" -d 'Install a skill from skills.sh or a GitHub owner/repo into .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and __fish_seen_subcommand_from skills" -f -a "new" -d 'Create a new local skill scaffold in .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and __fish_seen_subcommand_from skills" -f -a "rm" -d 'Remove a local skill from .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and __fish_seen_subcommand_from skills" -f -a "ls" -d 'List local skills in .dotagents/skills/'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and __fish_seen_subcommand_from commands" -f -a "new" -d 'Create a new command in .dotagents/commands/'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and __fish_seen_subcommand_from commands" -f -a "rm" -d 'Remove a command from .dotagents/commands/'
complete -c dotagents -n "__fish_dotagents_using_subcommand help; and __fish_seen_subcommand_from commands" -f -a "ls" -d 'List commands in .dotagents/commands/'
